package com.example.aviationsim;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    private Simulator simulator;
    private TextView txtOutput;
    private Button btnRunSimulation;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        txtOutput = findViewById(R.id.txtOutput);
        btnRunSimulation = findViewById(R.id.btnRunSimulation);

        // Initialize simulator
        simulator = new Simulator();
        simulator.addAircraft(new Aircraft("A101", "Fighter Jet", 0.95, 0.9, 0.97, 0.95));
        simulator.addAircraft(new Aircraft("A102", "Trainer Plane", 0.90, 0.8, 0.95, 0.93));
        simulator.addAircraft(new Aircraft("A103", "Commercial Jet", 0.92, 0.85, 0.96, 0.94));

        simulator.addEvent(new FlightEvent("High Winds", 0.2));
        simulator.addEvent(new FlightEvent("Air Traffic Congestion", 0.15));

        btnRunSimulation.setOnClickListener(v -> {
            String result = simulator.runSimulationUI();
            txtOutput.setText(result);
        });
    }
}
