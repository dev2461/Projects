import java.util.ArrayList;
import java.util.List;

public class Simulator {
    private List<Aircraft> aircrafts = new ArrayList<>();
    private List<FlightEvent> events = new ArrayList<>();

    public void addAircraft(Aircraft a) { aircrafts.add(a); }
    public void addEvent(FlightEvent e) { events.add(e); }

    public String runSimulationUI() {
        StringBuilder sb = new StringBuilder();
        sb.append("Running aviation simulation...\n\n");

        for (Aircraft a : aircrafts) {
            double totalStress = 0;
            for (FlightEvent e : events) totalStress += e.getStressFactor();
            totalStress = Math.min(totalStress, 1.0);

            boolean success = a.attemptFlight(totalStress);
            sb.append("Aircraft " + a.getId() + " (" + a.getType() + ") flight "
                    + (success ? "SUCCESSFUL" : "FAILED") + "\n");
        }

        return sb.toString();
    }
}
