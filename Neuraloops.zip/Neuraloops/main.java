public class Main {
    public static void main(String[] args) {
        Simulator sim = new Simulator();

        sim.addAircraft(new Aircraft("A101", "Fighter Jet", 0.95, 0.9, 0.97, 0.95));
        sim.addAircraft(new Aircraft("A102", "Trainer Plane", 0.90, 0.8, 0.95, 0.93));

        sim.addEvent(new FlightEvent("High Winds", 0.2));
        sim.addEvent(new FlightEvent("Air Traffic Congestion", 0.15));

        sim.runSimulation();
    }
}
