public class Aircraft {
    private String id;
    private String type;
    private double reliability;       // probability aircraft can complete a flight
    private double stressTolerance;   // reduces chance of failure under high-stress events
    private double takeoffSuccess;    // probability of successful takeoff
    private double landingSuccess;    // probability of successful landing

    public Aircraft(String id, String type, double reliability, double stressTolerance,
                    double takeoffSuccess, double landingSuccess) {
        this.id = id;
        this.type = type;
        this.reliability = reliability;
        this.stressTolerance = stressTolerance;
        this.takeoffSuccess = takeoffSuccess;
        this.landingSuccess = landingSuccess;
    }

    public boolean attemptFlight(double stressFactor) {
        double adjustedReliability = reliability * (1 - stressFactor * (1 - stressTolerance));
        return Math.random() <= adjustedReliability &&
               Math.random() <= takeoffSuccess &&
               Math.random() <= landingSuccess;
    }

    public String getId() { return id; }
    public String getType() { return type; }
}
