public class FlightEvent {
    private String description;
    private double stressFactor; // 0.0 to 1.0

    public FlightEvent(String description, double stressFactor) {
        this.description = description;
        this.stressFactor = stressFactor;
    }

    public double getStressFactor() { return stressFactor; }
    public String getDescription() { return description; }
}
