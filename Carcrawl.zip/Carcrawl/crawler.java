import java.util.*;

public class Sedan {
    private String make;
    private String model;
    private int year;
    private double mpg;
    private double price;

    public Sedan(String make, String model, int year, double mpg, double price) {
        this.make = make;
        this.model = model;
        this.year = year;
        this.mpg = mpg;
        this.price = price;
    }

    public String toString() {
        return year + " " + make + " " + model + " | MPG: " + mpg + " | Price: $" + price;
    }
}

public class SedanCrawler {

    public List<Sedan> fetchSedanData() {
        // Placeholder for actual web crawling logic
        List<Sedan> sedans = new ArrayList<>();
        sedans.add(new Sedan("Toyota", "Camry", 2024, 32, 26000));
        sedans.add(new Sedan("Honda", "Accord", 2024, 30, 28000));
        sedans.add(new Sedan("BMW", "3 Series", 2024, 28, 41000));
        return sedans;
    }

    public void displaySedans(List<Sedan> sedans) {
        for (Sedan s : sedans) {
            System.out.println(s);
        }
    }

    public static void main(String[] args) {
        SedanCrawler crawler = new SedanCrawler();
        List<Sedan> sedans = crawler.fetchSedanData();
        crawler.displaySedans(sedans);
    }
}
