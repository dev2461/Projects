public class BasketballPlayer {
    private String name;
    private double ppg;
    private double rpg;
    private double apg;
    private double fgPercentage;

    public BasketballPlayer(String name, double ppg, double rpg, double apg, double fgPercentage) {
        this.name = name;
        this.ppg = ppg;
        this.rpg = rpg;
        this.apg = apg;
        this.fgPercentage = fgPercentage;
    }

    public String getName() { return name; }

    public double getPerformanceScore() {
        return ppg * 0.5 + rpg * 0.2 + apg * 0.2 + fgPercentage * 0.1;
    }

    @Override
    public String toString() {
        return name;
    }
}
