import java.util.Random;

public class GameSimulator {

    private static final Random rand = new Random();

    public static String comparePlayers(BasketballPlayer p1, BasketballPlayer p2) {
        double score1 = p1.getPerformanceScore() * (0.9 + rand.nextDouble() * 0.2);
        double score2 = p2.getPerformanceScore() * (0.9 + rand.nextDouble() * 0.2);

        StringBuilder sb = new StringBuilder();
        sb.append("Comparing ").append(p1.getName()).append(" vs ").append(p2.getName()).append("\n");
        sb.append(p1.getName()).append(" score: ").append(String.format("%.2f", score1)).append("\n");
        sb.append(p2.getName()).append(" score: ").append(String.format("%.2f", score2)).append("\n");

        if (score1 > score2) sb.append(p1.getName()).append(" is likely to outperform!");
        else sb.append(p2.getName()).append(" is likely to outperform!");

        return sb.toString();
    }
}
