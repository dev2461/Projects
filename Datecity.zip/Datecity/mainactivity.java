package com.example.nbagamepredictor;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.Spinner;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    Spinner spinnerPlayer1, spinnerPlayer2;
    Button btnCompare;
    TextView txtResult;
    List<NBAPlayer> players;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        spinnerPlayer1 = findViewById(R.id.spinnerPlayer1);
        spinnerPlayer2 = findViewById(R.id.spinnerPlayer2);
        btnCompare = findViewById(R.id.btnCompare);
        txtResult = findViewById(R.id.txtResult);

        // Sample players
        players = new ArrayList<>();
        players.add(new BasketballPlayer("LeBron James", 30.1, 7.8, 7.5, 0.51));
        players.add(new BasketballPlayer("Stephen Curry", 29.5, 5.3, 6.2, 0.48));
        players.add(new BasketballPlayer("Kevin Durant", 28.2, 7.1, 5.5, 0.52));

        ArrayAdapter<BasketballPlayer> adapter = new ArrayAdapter<>(this,
                android.R.layout.simple_spinner_item, players);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);

        spinnerPlayer1.setAdapter(adapter);
        spinnerPlayer2.setAdapter(adapter);

        btnCompare.setOnClickListener(v -> {
            BasketballPlayer p1 = (BasketballPlayer) spinnerPlayer1.getSelectedItem();
            BasketballPlayer p2 = (BasketballPlayer) spinnerPlayer2.getSelectedItem();

            String result = GameSimulator.comparePlayers(p1, p2);
            txtResult.setText(result);
        });
    }
}
