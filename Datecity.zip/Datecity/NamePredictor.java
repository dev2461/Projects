public class NamePredictor {

    public static void comparePlayers(BasketballPlayer p1, BasketballPlayer p2) {
        double score1 = p1.getPerformanceScore() * (0.9 + Math.random() * 0.2); // add randomness
        double score2 = p2.getPerformanceScore() * (0.9 + Math.random() * 0.2);

        System.out.println("Comparing " + p1.getName() + " vs " + p2.getName());
        System.out.println(p1.getName() + " score: " + String.format("%.2f", score1));
        System.out.println(p2.getName() + " score: " + String.format("%.2f", score2));

        if (score1 > score2) System.out.println(p1.getName() + " is likely to outperform!");
        else System.out.println(p2.getName() + " is likely to outperform!");
    }

    public static void main(String[] args) {
        BasketballPlayer lebron = new BasketballPlayer("LeBron James", 30.1, 7.8, 7.5, 0.51);
        BasketballPlayer curry = new BasketballPlayer("Stephen Curry", 29.5, 5.3, 6.2, 0.48);

        comparePlayers(lebron, curry);
    }
}
