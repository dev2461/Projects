public class LayoffCalculator {

    public static double calculateLayoffRisk(double interviewSuccess, double companyVolatility,
                                              double roleRisk, double economicStress) {
        double hireProbability = interviewSuccess;
        double layoffProbability = (companyVolatility + roleRisk + economicStress) / 3;
        double finalRisk = layoffProbability * (1 - hireProbability);
        return finalRisk;
    }
}
