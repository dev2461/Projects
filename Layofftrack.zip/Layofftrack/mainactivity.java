package com.example.layofftracker;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    EditText inputInterview, inputCompany, inputRole, inputStress;
    Button btnCalculate;
    TextView txtResult;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        inputInterview = findViewById(R.id.inputInterview);
        inputCompany = findViewById(R.id.inputCompany);
        inputRole = findViewById(R.id.inputRole);
        inputStress = findViewById(R.id.inputStress);
        btnCalculate = findViewById(R.id.btnCalculate);
        txtResult = findViewById(R.id.txtResult);

        btnCalculate.setOnClickListener(v -> {
            double interview = Double.parseDouble(inputInterview.getText().toString());
            double company = Double.parseDouble(inputCompany.getText().toString());
            double role = Double.parseDouble(inputRole.getText().toString());
            double stress = Double.parseDouble(inputStress.getText().toString());

            double risk = LayoffCalculator.calculateLayoffRisk(interview, company, role, stress);
            String result = String.format("Predicted layoff probability: %.2f%%\n", risk * 100);

            if (risk < 0.2) result += "Low risk of layoff.";
            else if (risk < 0.5) result += "Moderate risk of layoff.";
            else result += "High risk of layoff.";

            txtResult.setText(result);
        });
    }
}
