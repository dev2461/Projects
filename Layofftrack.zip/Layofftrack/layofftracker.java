import java.util.Scanner;

public class LayoffTracker {

    public static double calculateLayoffRisk(double interviewSuccess, double companyVolatility,
                                              double roleRisk, double economicStress) {
        // Start with probability of being hired
        double hireProbability = interviewSuccess;

        // Adjust based on company and role risk
        double layoffProbability = (companyVolatility + roleRisk + economicStress) / 3;

        // Combine with hire probability: the higher hire chance, the less likely immediate layoff
        double finalRisk = layoffProbability * (1 - hireProbability);

        return finalRisk;
    }

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.println("Enter interview success probability (0.0 - 1.0):");
        double interview = scanner.nextDouble();

        System.out.println("Enter company volatility (0.0 - 1.0):");
        double company = scanner.nextDouble();

        System.out.println("Enter role risk (0.0 - 1.0):");
        double role = scanner.nextDouble();

        System.out.println("Enter economic stress factor (0.0 - 1.0):");
        double stress = scanner.nextDouble();

        double layoffRisk = calculateLayoffRisk(interview, company, role, stress);

        System.out.println("Predicted layoff probability: " + (layoffRisk * 100) + "%");

        if (layoffRisk < 0.2) {
            System.out.println("Low risk of layoff.");
        } else if (layoffRisk < 0.5) {
            System.out.println("Moderate risk of layoff.");
        } else {
            System.out.println("High risk of layoff.");
        }
    }
}
