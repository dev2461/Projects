package com.example.nationalrailsim;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    private Simulator simulator;
    private TextView txtOutput;
    private Button btnRunSimulation;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        txtOutput = findViewById(R.id.txtOutput);
        btnRunSimulation = findViewById(R.id.btnRunSimulation);

        // Initialize simulator
        simulator = new Simulator();
        simulator.addTrain(new Train("T101", "London", "Manchester", 0.95));
        simulator.addTrain(new Train("T102", "Birmingham", "Liverpool", 0.90));

        simulator.addEvent(new Event("Heavy Rain", 0.2));
        simulator.addEvent(new Event("Track Maintenance", 0.1));

        btnRunSimulation.setOnClickListener(v -> {
            String result = simulator.runSimulationUI();
            txtOutput.setText(result);
        });
    }
}
