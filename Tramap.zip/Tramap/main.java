public class Main {
    public static void main(String[] args) {
        Simulator sim = new Simulator();

        // Add trains
        sim.addTrain(new Train("T101", "London", "Manchester", 0.95));
        sim.addTrain(new Train("T102", "Birmingham", "Liverpool", 0.90));

        // Add events
        sim.addEvent(new Event("Heavy Rain", 0.2));
        sim.addEvent(new Event("Track Maintenance", 0.1));

        // Run simulation
        sim.runSimulation();
    }
}
