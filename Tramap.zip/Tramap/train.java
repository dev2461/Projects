public class Train {
    private String id;
    private String origin;
    private String destination;
    private double reliability; // Probability train runs on time (0.0 to 1.0)

    public Train(String id, String origin, String destination, double reliability) {
        this.id = id;
        this.origin = origin;
        this.destination = destination;
        this.reliability = reliability;
    }

    public boolean willRun() {
        return Math.random() <= reliability;
    }

    public String getId() { return id; }
    public String getOrigin() { return origin; }
    public String getDestination() { return destination; }
}
