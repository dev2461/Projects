import java.util.ArrayList;
import java.util.List;

public class Simulator {
    private List<Train> trains = new ArrayList<>();
    private List<Event> events = new ArrayList<>();

    public void addTrain(Train train) { trains.add(train); }
    public void addEvent(Event event) { events.add(event); }

    public String runSimulationUI() {
        StringBuilder sb = new StringBuilder();
        sb.append("Running simulation...\n\n");

        for (Train train : trains) {
            double adjustedReliability = train.getReliability();
            for (Event event : events) {
                adjustedReliability *= (1 - event.getImpact());
            }
            boolean runs = Math.random() <= adjustedReliability;
            sb.append("Train " + train.getId() + " from " + train.getOrigin() + " to "
                    + train.getDestination() + " will " + (runs ? "run on time" : "be delayed/cancelled") + "\n");
        }

        return sb.toString();
    }
}
