public class Event {
    private String description;
    private double impact; // Reduces reliability by this factor (0.0 to 1.0)

    public Event(String description, double impact) {
        this.description = description;
        this.impact = impact;
    }

    public double getImpact() { return impact; }
    public String getDescription() { return description; }
}
